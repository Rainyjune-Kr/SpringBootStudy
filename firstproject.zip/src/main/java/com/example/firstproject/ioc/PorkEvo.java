package com.example.firstproject.ioc;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PorkEvo extends Ingredient{
    public PorkEvo(String name) {
        super(name);
    }
}
